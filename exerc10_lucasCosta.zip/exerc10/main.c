#include <stdio.h>
#include <stdlib.h>
#include "listaEncadeada.h"
#include "arquivos.h"
#include <string.h>

#define MAX_LISTAS 20
#define TAM_MAT 12

void menu(Lista **l[], Aluno *alunos, int qtdAlunos);
int funcaoHash(char *matriculaAluno, int tamArray);

int main(int argc, char *argv[]) {
	
	int i = 0, qtdAlunos = 0;
	Aluno *alunos;
	Lista **l[MAX_LISTAS];
	
	readFile(&alunos,"alunos.dat","rb",sizeof(Aluno),&qtdAlunos);
	
	for(i=0;i<MAX_LISTAS;i++){
		l[i] = criar_lista();
	}
	
	menu(l,alunos,qtdAlunos);
	
	return 0;
}

void menu(Lista **l[], Aluno *alunos, int qtdAlunos){
	
	int opcao = 0;
	int qtdAlunosInclusos = 0;
	int indice = 0;
	int i = 0;
	char matriculaAluno[TAM_MAT];
	
	do{
		printf("\tMENU\n\n");
		printf("1 - Incluir alunos na listas\n");
		printf("2 - Listagem das listas\n");
		printf("3 - Consultar aluno nas listas\n");
		printf("4 - Encerrar programa\n");
		scanf("%d", &opcao);system("cls");
		
		switch(opcao){
			case 1:
				if(qtdAlunosInclusos < qtdAlunos){	
					indice = funcaoHash(alunos[qtdAlunosInclusos].matricula,MAX_LISTAS);
					
					if(incluir_elemento_lista(l[indice],&alunos[qtdAlunosInclusos])){
						printf("Aluno(a) %s incluso com sucesso na Lista %d\n",alunos[qtdAlunosInclusos].nome ,indice);
					}
					qtdAlunosInclusos++;
					
				}else{
					printf("Todos os alunos foram cadastrados\n");
				}
				getch();
				break;
			case 2:
				for(i=0;i<MAX_LISTAS;i++){
					printf("Lista %d\n\n", i+1);
					if(!imprimir_lista(l[i])){
						printf("Lista Vazia\n");
					}
					printf("--------------\n");
				}
				getch();
				break;
			case 3:
				fflush(stdin);
				printf("\tBuscar Aluno\n\n");
				printf("Matricula Aluno: ");
				scanf("%[^\n]s", &matriculaAluno);
				for(i=0;i<2;i++){
					//Colocando em maiusculo as letras iniciais
					matriculaAluno[i] = toupper(matriculaAluno[i]);
				}
				//Indice da lista
				indice = funcaoHash(matriculaAluno,MAX_LISTAS);
				
				if(consulta_lista(l[indice],matriculaAluno)){
					printf("Aluno Encontrado -> Lista %d\n",indice);getch();
				}else{
					printf("Nenhum aluno encontrado\n");
				}
				break;
			case 4:
				exit(0);
			default:
				printf("Escolha Invalida\nDigite Novamente\n");getch();			
		}
		system("cls");
	}while(opcao!=5);
	
}

int funcaoHash(char *matriculaAluno, int tamArray){
	
	int indice = 0;
	int i = 0;
	
	for(i=0;i<strlen(matriculaAluno);i++){
		indice += (int) matriculaAluno[i];
	} 
	
	if(indice % 2 == 0){
		indice += 17;
	}else if(indice % 10 == 0){
		indice /= 3;
	}
	
	return indice % tamArray;
}
