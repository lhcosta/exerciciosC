#ifndef ARQUIVOS
#define ARQUIVOS

#include "listaEncadeada.h"

void readFile(Aluno **alunos, char *nameFile, char *typeFile, int sizeData, int *qtdData);

#endif
